package com.example.ecommercecheck1.Prevalent;

import com.example.ecommercecheck1.Model.Users;

public class Prevalent {
    private  static Users currentOnlineUser;

    //public static final String UserPhoneKey = "UserPhone";
    //public static final String UserPasswordKey ="UserPassword";
}
